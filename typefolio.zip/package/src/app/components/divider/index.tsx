
const Divider = () => {
    return (
        <div className="container">
            <div className="h-4 border border-primary/10" />
        </div>
    )
}

export default Divider